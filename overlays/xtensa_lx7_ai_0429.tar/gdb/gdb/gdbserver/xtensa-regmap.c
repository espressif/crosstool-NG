/* Customized table mapping between kernel xtregset and GDB register cache.

   Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	248

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   75, 300,   8,   8,  4, -1, 0x0204, "br" },
  {   76, 304,  12,  12,  4, -1, 0x020c, "scompare1" },
  {   77, 308,   0,   0,  4, -1, 0x0210, "acclo" },
  {   78, 312,   4,   4,  4, -1, 0x0211, "acchi" },
  {   79, 316,  16,  16,  4, -1, 0x0220, "m0" },
  {   80, 320,  20,  20,  4, -1, 0x0221, "m1" },
  {   81, 324,  24,  24,  4, -1, 0x0222, "m2" },
  {   82, 328,  28,  28,  4, -1, 0x0223, "m3" },
  {   83, 332,  32,  32, 16, -1, 0x1008, "q0" },
  {   84, 348,  48,  48, 16, -1, 0x1009, "q1" },
  {   85, 364,  64,  64, 16, -1, 0x100a, "q2" },
  {   86, 380,  80,  80, 16, -1, 0x100b, "q3" },
  {   87, 396,  96,  96, 16, -1, 0x100c, "q4" },
  {   89, 420,   8, 120,  8,  0, 0x0030, "f0" },
  {   90, 428,  16, 128,  8,  0, 0x0031, "f1" },
  {   91, 436,  24, 136,  8,  0, 0x0032, "f2" },
  {   92, 444,  32, 144,  8,  0, 0x0033, "f3" },
  {   93, 452,  40, 152,  8,  0, 0x0034, "f4" },
  {   94, 460,  48, 160,  8,  0, 0x0035, "f5" },
  {   95, 468,  56, 168,  8,  0, 0x0036, "f6" },
  {   96, 476,  64, 176,  8,  0, 0x0037, "f7" },
  {   97, 484,  72, 184,  8,  0, 0x0038, "f8" },
  {   98, 492,  80, 192,  8,  0, 0x0039, "f9" },
  {   99, 500,  88, 200,  8,  0, 0x003a, "f10" },
  {  100, 508,  96, 208,  8,  0, 0x003b, "f11" },
  {  101, 516, 104, 216,  8,  0, 0x003c, "f12" },
  {  102, 524, 112, 224,  8,  0, 0x003d, "f13" },
  {  103, 532, 120, 232,  8,  0, 0x003e, "f14" },
  {  104, 540, 128, 240,  8,  0, 0x003f, "f15" },
  {  105, 548,   0, 112,  4,  0, 0x03e8, "fcr" },
  {  106, 552,   4, 116,  4,  0, 0x03e9, "fsr" },
  { 0 }
};

