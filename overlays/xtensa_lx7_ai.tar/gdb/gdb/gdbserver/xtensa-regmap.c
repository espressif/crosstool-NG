/* Customized table mapping between kernel xtregset and GDB register cache.

   Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	416

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   75, 300,   8,   8,  4, -1, 0x0204, "br" },
  {   76, 304,  12,  12,  4, -1, 0x020c, "scompare1" },
  {   77, 308,   0,   0,  4, -1, 0x0210, "acclo" },
  {   78, 312,   4,   4,  4, -1, 0x0211, "acchi" },
  {   79, 316,  16,  16,  4, -1, 0x0220, "m0" },
  {   80, 320,  20,  20,  4, -1, 0x0221, "m1" },
  {   81, 324,  24,  24,  4, -1, 0x0222, "m2" },
  {   82, 328,  28,  28,  4, -1, 0x0223, "m3" },
  {   84, 336,   8,  40,  8,  0, 0x0030, "f0" },
  {   85, 344,  16,  48,  8,  0, 0x0031, "f1" },
  {   86, 352,  24,  56,  8,  0, 0x0032, "f2" },
  {   87, 360,  32,  64,  8,  0, 0x0033, "f3" },
  {   88, 368,  40,  72,  8,  0, 0x0034, "f4" },
  {   89, 376,  48,  80,  8,  0, 0x0035, "f5" },
  {   90, 384,  56,  88,  8,  0, 0x0036, "f6" },
  {   91, 392,  64,  96,  8,  0, 0x0037, "f7" },
  {   92, 400,  72, 104,  8,  0, 0x0038, "f8" },
  {   93, 408,  80, 112,  8,  0, 0x0039, "f9" },
  {   94, 416,  88, 120,  8,  0, 0x003a, "f10" },
  {   95, 424,  96, 128,  8,  0, 0x003b, "f11" },
  {   96, 432, 104, 136,  8,  0, 0x003c, "f12" },
  {   97, 440, 112, 144,  8,  0, 0x003d, "f13" },
  {   98, 448, 120, 152,  8,  0, 0x003e, "f14" },
  {   99, 456, 128, 160,  8,  0, 0x003f, "f15" },
  {  100, 464,   0,  32,  4,  0, 0x03e8, "fcr" },
  {  101, 468,   4,  36,  4,  0, 0x03e9, "fsr" },
  {  102, 472,   0, 176,  4,  3, 0x0300, "accx_0" },
  {  103, 476,   4, 180,  4,  3, 0x0301, "accx_1" },
  {  104, 480,   8, 184,  4,  3, 0x0302, "qacc_h_0" },
  {  105, 484,  12, 188,  4,  3, 0x0303, "qacc_h_1" },
  {  106, 488,  16, 192,  4,  3, 0x0304, "qacc_h_2" },
  {  107, 492,  20, 196,  4,  3, 0x0305, "qacc_h_3" },
  {  108, 496,  24, 200,  4,  3, 0x0306, "qacc_h_4" },
  {  109, 500,  28, 204,  4,  3, 0x0307, "qacc_l_0" },
  {  110, 504,  32, 208,  4,  3, 0x0308, "qacc_l_1" },
  {  111, 508,  36, 212,  4,  3, 0x0309, "qacc_l_2" },
  {  112, 512,  40, 216,  4,  3, 0x030a, "qacc_l_3" },
  {  113, 516,  44, 220,  4,  3, 0x030b, "qacc_l_4" },
  {  114, 520,  48, 224,  4,  3, 0x030c, "fft_state_q0_0" },
  {  115, 524,  52, 228,  4,  3, 0x030d, "fft_state_q0_1" },
  {  116, 528,  56, 232,  4,  3, 0x030e, "fft_state_q0_2" },
  {  117, 532,  60, 236,  4,  3, 0x030f, "fft_state_q0_3" },
  {  118, 536,  64, 240,  4,  3, 0x0310, "fft_state_q1_0" },
  {  119, 540,  68, 244,  4,  3, 0x0311, "fft_state_q1_1" },
  {  120, 544,  72, 248,  4,  3, 0x0312, "fft_state_q1_2" },
  {  121, 548,  76, 252,  4,  3, 0x0313, "fft_state_q1_3" },
  {  122, 552,  80, 256,  4,  3, 0x0314, "fft_state_q2_0" },
  {  123, 556,  84, 260,  4,  3, 0x0315, "fft_state_q2_1" },
  {  124, 560,  88, 264,  4,  3, 0x0316, "fft_state_q2_2" },
  {  125, 564,  92, 268,  4,  3, 0x0317, "fft_state_q2_3" },
  {  126, 568,  96, 272,  4,  3, 0x0318, "fft_state_q3_0" },
  {  127, 572, 100, 276,  4,  3, 0x0319, "fft_state_q3_1" },
  {  128, 576, 104, 280,  4,  3, 0x031a, "fft_state_q3_2" },
  {  129, 580, 108, 284,  4,  3, 0x031b, "fft_state_q3_3" },
  {  130, 584, 112, 288, 16,  3, 0x1008, "q0" },
  {  131, 600, 128, 304, 16,  3, 0x1009, "q1" },
  {  132, 616, 144, 320, 16,  3, 0x100a, "q2" },
  {  133, 632, 160, 336, 16,  3, 0x100b, "q3" },
  {  134, 648, 176, 352, 16,  3, 0x100c, "q4" },
  {  135, 664, 192, 368, 16,  3, 0x100d, "q5" },
  {  136, 680, 208, 384, 16,  3, 0x100e, "q6" },
  {  137, 696, 224, 400, 16,  3, 0x100f, "q7" },
  { 0 }
};

